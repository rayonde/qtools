﻿#include <iostream>
#include "smncsftmt.h"
#include <thread>
#include <fstream>
#include <chrono>
#include <string.h>
#include <cstddef>
#include <cstdint>

using namespace std;

int testT1()
{
	float times = 10;

	int nDevId = 0;
	int nRunMode = 1;
	int nSaveMode = 1;
	int nFilterMode = 1;

	int nBin = 65536;

	uint32_t nChl = CH_MASK_0 | CH_MASK_1 | CH_MASK_2 | CH_MASK_3 | CH_MASK_4 | CH_MASK_5 | CH_MASK_6 | CH_MASK_7 | CH_MASK_8 | CH_MASK_9 |
		CH_MASK_10 | CH_MASK_11 | CH_MASK_12 | CH_MASK_13 | CH_MASK_14 | CH_MASK_15;

	//第一步：设置任务运行时间
	if (SetStatisticsTime(nRunMode, 1) != FTMT_ERROR_NONE)//统计时间10s   
	{
		std::cerr << "SetStatisticsTime Error" << std::endl;
		return -1;
	}

  //第二步：设置文件保存类型，柱状图（T1）只能选择保存为TXT或者不保存
	if (SetFileMode(nRunMode, FTMT_FILE_SAVE_MODE_NONE, FTMT_FILE_SERIES_MODE_EACH) != FTMT_ERROR_NONE)
	{
		std::cerr << "SetFileMode Error" << std::endl;
		return -1;
	}

	//第三步：设备保存文件的路径
	if (SetFilePath(nDevId, nRunMode, "E:\\Siminics") != FTMT_ERROR_NONE)
	{
		std::cerr << "SetFilePath Error" << std::endl;
		return -1;
	}

	//第四步：设置T1采集时间间隔
	if (SetT1Interval(0.1f) != FTMT_ERROR_NONE)
	{
		std::cout << "SetT1Interval Error" << std::endl;
		return -1;
	}

	//第五步（可选）：设置设备分辨率
	if (SetTimeWindowRes(0, 6) != FTMT_ERROR_NONE)  //7=128
	{
		std::cout << "SetTimeWindowRes Error" << std::endl;
		return false;
	}

	//第六步：设置Bin的个数
	if (SetBinSize(nDevId, nBin) != FTMT_ERROR_NONE)
	{
		std::cout << "SetBinSize Error" << std::endl;
		return -1;
	}

	//第七步：设置柱状图最大值
	if (SetMaxBarValue(65536) != FTMT_ERROR_NONE)
	{
		std::cout << "SetMaxBarValue Error" << std::endl;
		return -1;
	}

	//第八步：使能T1模式
	if (EnableT1(nDevId, 0, nChl) != FTMT_ERROR_NONE)
	{
		std::cout << "EnbaleT1 Error" << std::endl;
		return -1;
	}
	auto ittr_start_time = std::chrono::system_clock::now();
	std::cout << "Start " << std::endl;
		
	//第九步：开始任务
	if (StartTask(nRunMode) != FTMT_ERROR_NONE)
	{
		std::cout << "StartTask Error" << std::endl;
		return -1;
	}

	auto start_end_time = std::chrono::system_clock::now();

	/*uint64_t* datadata = nullptr;
	datadata = new uint64_t[100000];
	memset(datadata, 0, 100000);*/
	float nTimes = 1 / 0.1;
	unsigned int nLastRefreshCount = 0;
	unsigned int nMax = 0;
	unsigned int nXLastNoZeroValue = 0;
	unsigned long long uYMax64 = 0;
	uint64_t nRefreshCount = 0;

	unsigned long long* datadata = nullptr;
	datadata = new unsigned long long[FTMT_T1_DATA_LEN];
	memset(datadata, 0, FTMT_T1_DATA_LEN);
	char filename[256]{ 0 };
	
	//第十步：判断任务结束（注：即使自己手动调用StopTask停止，之后也要调用此函数）
	while (IsTaskCompleted() != FTMT_ERROR_NONE)
	{
		std::this_thread::sleep_for(std::chrono::milliseconds(100));

		GetT1Status(&nMax, &nXLastNoZeroValue, &uYMax64, &nRefreshCount, filename);
		if (GetT1Data(0, 0, datadata) != FTMT_ERROR_NONE)
		{
			continue;
		}
	}

	delete[]datadata;
	datadata = nullptr;

	auto task_end_time = std::chrono::system_clock::now();
	auto start_elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(start_end_time - ittr_start_time);

	auto task_elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(task_end_time - ittr_start_time);


	std::cout << "StartTask Consumed: " << start_elapsed.count() << "    Total time: " << task_elapsed.count() << std::endl;
}

#include <string>
void testIttr()
{
	//SetTimeWindowRes(0, 8);

	int nTaskRunMode = FTMT_TASK_RUN_MODE_ITTR_T;

	int ittr_intvl = 1000000;  
	float statistics_time = 1;


	//第一步：设置任务采集时间
	if (SetStatisticsTime(nTaskRunMode, 100) != FTMT_ERROR_NONE)//统计时间10s   
	{
		std::cerr << "SetStatisticsTime Error" << std::endl;
	}

	//第二步：设置保存文件模式
	if (SetFileMode(nTaskRunMode, FTMT_FILE_SAVE_MODE_BIN, FTMT_FILE_SERIES_MODE_EACH) != FTMT_ERROR_NONE)
	{
		std::cerr << "SetFileMode Error" << std::endl;
	}


		int n = CH_MASK_0 | CH_MASK_1;

		uint16_t uMask16 = CH_MASK_0 | CH_MASK_1 | CH_MASK_2 | CH_MASK_3;
		//第三步：使能ITTR模式
		if (EnableITTR(devid, FTMT_BOARD_A, CH_MASK_ALL) != FTMT_ERROR_NONE)//BOARD A, CHANNEL 0  
		{
			std::cerr << "EnableITTR Error" << std::endl;
		}

	  //第四步：设置ITTR模式的采集周期
		if (SetITTRInterval(devid, FTMT_BOARD_A, ittr_intvl) != FTMT_ERROR_NONE)
		{
			std::cerr << "SetITTRInterval Error" << std::endl;
		}

		//第五步：设置单个文件的大小（可选）
		if (SetMaxFileSize(nTaskRunMode, 0, 512, 100) != FTMT_ERROR_NONE)
		{
			std::cerr << "SetMaxFileSize Error" << std::endl;
		}

		//第六步：设置文件保存的路径
		if (SetFilePath(devid, nTaskRunMode, "D:\\Siminics") != FTMT_ERROR_NONE)
		{
			std::cerr << "SetFilePath Error" << std::endl;
		}


		//第七步：设置停止模式
		if (SetITTREndMode(FTMT_ITTR_END_MODE_TIME, 0) != FTMT_ERROR_NONE) //用户停止，非自动停止
			//if (SetITTREndMode(FTMT_TTTR_END_MODE_EVENT,100) != FTMT_ERROR_NONE) //用户停止，非自动停止
		{
			std::cerr << "SetITTREndMode Error" << std::endl;
		}


		//第八步：打开内粗模式（要是想实时获取原始数据，此设置此接口为true，否则不用关注）
		//SetMemoryDataMode(true);

		auto ittr_start_time = std::chrono::system_clock::now();
		
		//第九步：开启任务采集
		if (StartTask(nTaskRunMode) != FTMT_ERROR_NONE)//StartTask ITTR_T
		{
			std::cerr << "StartTask Error" << std::endl;
			continue;
		}

		auto start_end_time = std::chrono::system_clock::now();

		FILE* fp = nullptr;
		fopen_s(&fp, "C:\\Users\\Mayn\\Desktop\\星秒光电\\1.dat", "wb");

		char strPath[_MAX_PATH]{ 0 };
		char buffer[1024]{ 0 };
		unsigned int arrIntensity[32]{ 0 };
		//第十步：判断任务结束（注：即使自己手动调用StopTask停止，之后也要调用此函数）
		while (IsTaskCompleted() != FTMT_ERROR_NONE)
		{
			std::this_thread::sleep_for(std::chrono::milliseconds(10));
			//std::cout << "GetFileName:" << GetFileName(0, false, buffer, 1024) << "___:" << buffer << std::endl;

			GetIttrTIntensity(arrIntensity, 32);
			//for (int i = 0; i < 2; i++)
			//{
			//	std::cout << "arrIntensity i:" << i << ",,,value" << arrIntensity[i] << std::endl;
			//}
			/*FtmtRawData* dat_ptr = GetMemoryData(0);
			if (dat_ptr)
			{
				if (nullptr != fp)
				{
					fwrite(dat_ptr->ptrData, 1, dat_ptr->lLength, fp);
					std::cout << "dat_ptr->lLength:" << dat_ptr->lLength << std::endl;
				}

				ReleaseMemoryData(dat_ptr);
			}*/

			//long len = 0;
			//int nType = 0;
			//unsigned char* data = GetMemoryData(0, &len, nType);
			//if (data != nullptr)
			//{
			//	if (nullptr != fp)
			//	{
			//		fwrite(data, 1, len, fp);
			//	}
			//}

			//ReleaseMemoryData(data);
		}

		if (fp)
		{
			fclose(fp);
			fp = nullptr;
		}

		auto task_end_time = std::chrono::system_clock::now();


		auto start_elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(start_end_time - ittr_start_time);

		auto task_elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(task_end_time - ittr_start_time);


		std::cout << "StartTask Consumed: " << start_elapsed.count() << "    Total time: " << task_elapsed.count() << std::endl;
}

void testIttrM()
{
	int nTaskRunMode = FTMT_TASK_RUN_MODE_ITTR_M;

	int ittr_intvl = 100;

	float statistics_time = 1;


	//第一步：设置采集时间
	if (SetStatisticsTime(nTaskRunMode, statistics_time) != FTMT_ERROR_NONE)//统计时间10s   
	{
		std::cerr << "SetStatisticsTime Error" << std::endl;
	}

	//第二步：设置文件保存类型
	if (SetFileMode(nTaskRunMode, FTMT_FILE_SAVE_MODE_TEXT, FTMT_FILE_SERIES_MODE_EACH) != FTMT_ERROR_NONE)
	{
		std::cerr << "SetFileMode Error" << std::endl;
	}


		uint16_t uMask16 = CH_MASK_0 | CH_MASK_1 | CH_MASK_2 | CH_MASK_3 | CH_MASK_4 | CH_MASK_5 | CH_MASK_6 | CH_MASK_7;
		//第三步：使能ITTR模式
		if (EnableITTR(devid, FTMT_BOARD_A, uMask16) != FTMT_ERROR_NONE)//BOARD A, CHANNEL 0  
		{
			std::cerr << "EnableITTR Error" << std::endl;
		}

		//第三步：设置ITTR模式的周期
		if (SetITTRInterval(devid, FTMT_BOARD_A, ittr_intvl) != FTMT_ERROR_NONE)
		{
			std::cerr << "SetITTRInterval Error" << std::endl;
		}

		//第四步：设置保存文件的路径
		if (SetFilePath(devid, nTaskRunMode, "C:\\Users\\Mayn\\Desktop\\星秒光电") != FTMT_ERROR_NONE)
		{
			std::cerr << "SetFilePath Error" << std::endl;
		}

		//第五步：设置停止方式
		if (SetITTREndMode(FTMT_ITTR_END_MODE_TIME, 0) != FTMT_ERROR_NONE) //用户停止，非自动停止
			//if (SetITTREndMode(FTMT_TTTR_END_MODE_EVENT, 65536) != FTMT_ERROR_NONE) //用户停止，非自动停止
		{
			std::cerr << "SetITTREndMode Error" << std::endl;
		}

		auto ittr_start_time = std::chrono::system_clock::now();
			
		//第六步：开始任务采集
		if (StartTask(nTaskRunMode) != FTMT_ERROR_NONE)//StartTask ITTR_T
		{
			std::cerr << "StartTask Error" << std::endl;
			continue;
		}

		auto start_end_time = std::chrono::system_clock::now();

	 //第七步：判断任务结束（注：即使自己手动调用StopTask停止，之后也要调用此函数）
		while (IsTaskCompleted() != FTMT_ERROR_NONE) {

		}

		auto task_end_time = std::chrono::system_clock::now();


		auto start_elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(start_end_time - ittr_start_time);

		auto task_elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(task_end_time - ittr_start_time);


		std::cout << "StartTask Consumed: " << start_elapsed.count() << "    Total time: " << task_elapsed.count() << std::endl;
}

const std::size_t DATA_TAIL_LENGTH = 4;  //数据尾大小
const uint8_t strDataEnd[] = { uint8_t(0xEE),uint8_t(0xEE),uint8_t(0xDD),uint8_t(0xDD) };
inline bool IsDataEndSign(uint8_t* dptr, long length)
{
	return (memcmp(dptr + (length - DATA_TAIL_LENGTH), strDataEnd, DATA_TAIL_LENGTH) == 0);
}

void StartT2Default()
{
	int nBoard = FTMT_BOARD_D;
	int nMask = CH_MASK_0 |
		CH_MASK_9 | CH_MASK_10 | CH_MASK_11 | CH_MASK_12 | CH_MASK_13 | CH_MASK_14 | CH_MASK_15;
	int nRunMode = FTMT_TASK_RUN_MODE_T2;
	int nSaveMode = FTMT_FILE_SAVE_MODE_TEXT;
	int nFilterMode = FTMT_FILE_SERIES_MODE_EACH;
	int nConnectionSucceeded = 0;                                                                
	int nStartThreShold = 1000; //OK
	int nStopThreShold = 1000;  //OK
	int nEndMode = FTMT_TTTR_END_MODE_TIME;
	float nInterval = 0.1f;
	bool isEnableMemory = true;
	float fstatisticstimes = 10;
	bool isEnablePermanentTask = true;
	bool isConcurrentMode = false;
	int nMaxEvent = 1000;

	//第一步：设置采集时间
	if (FTMT_ERROR_NONE != SetStatisticsTime(nRunMode, 1))
	{
		std::cout << "T2 功能测试时 SetStatisticsTime 设置失败" << std::endl;

		return;
	}

  //第二步：设置保存文件类型
	if (FTMT_ERROR_NONE != SetFileMode(nRunMode, FTMT_FILE_SAVE_MODE_BIN, FTMT_FILE_SERIES_MODE_LAST))
	{
		std::cout << "T2 功能测试时 SetFileMode 设置失败：" << nSaveMode << std::endl;

		return;
	}

	//第三步：设置保存文件的大小（可选）
	if (SetMaxFileSize(nRunMode, 0, 1024, 100) != FTMT_ERROR_NONE)
	{
		std::cerr << "SetMaxFileSize Error" << std::endl;
	}


	//获取设备类型
	//第四步：设置文件保存路径
	if (FTMT_ERROR_NONE != SetFilePath(0, nRunMode, "G:\\Siminics"))
	{
		std::cout << "设备Id为：" << 0 << ",对应的文件保存路径设置失败!" << std::endl;
	}

	//第五步：设置保存的文件名（可选）
	if (FTMT_ERROR_NONE != SetFileName(0, nRunMode, 0, "123456"))
	{
		std::cout << "设备Id为：" << 0 << ",对应的文件保存路径设置失败!" << std::endl;
	}

	//使能T2模式
	//第六步：使能TTTR模式
	if (FTMT_ERROR_NONE != EnableTTTR(0, FTMT_BOARD_A, CH_MASK_ALL))
	{
		std::cout << "设备Id：" << 0 << ",板" << nBoard << ",使能失败" << std::endl;
	}

	//第七步：设置TTTR模式的停止方式
	if (FTMT_ERROR_NONE != SetTTTREndMode(FTMT_TTTR_END_MODE_TIME, 0))
	{
		std::cout << "时间停止方式设置失败" << std::endl;
		return;
	}
	else
	{
		std::cout << "时间停止方式设置成功" << std::endl;
	}

	StartChannelMapping(0, 0, 0);

	//第八步：设置TTTR的内存模式（当需要读取内存中的原始数据时，设置此函数为true，否则不要关心）
	//SetMemoryDataMode(true);

	std::chrono::time_point<std::chrono::system_clock> ittr_start_t = std::chrono::system_clock::now();

	//第九步：开始采集
	if (FTMT_ERROR_NONE != StartTask(nRunMode))
	{
		std::cerr << "StartTask Error!" << std::endl;
	}

	//FILE* fp = nullptr;
	//std::string strIndex = "E:\\Siminics\\T2.dat";
	//fopen_s(&fp, strIndex.c_str(), "wb");

	int nCount = 0;
	//第十步：判断任务结束（注：即使自己手动调用StopTask停止，之后也要调用此函数）
	while (IsTaskCompleted() != FTMT_ERROR_NONE)
	{
		std::this_thread::sleep_for(std::chrono::milliseconds(50));
		//第十一步：读取并处理内存中的数据
		//FtmtRawData* dat_ptr = GetMemoryData(0);
		//if (dat_ptr)
		//{
		//	//std::cout << "dat_ptr->lLength："<< dat_ptr->lLength << std::endl;
		//	if (nullptr != fp)
		//	{
		//		fwrite(dat_ptr->ptrData, 1, dat_ptr->lLength, fp);
		//		if (IsDataEndSign(dat_ptr->ptrData, dat_ptr->lLength))
		//		{
		//			ReleaseMemoryData(dat_ptr);
		//			break;
		//		}
		//	}

		//	ReleaseMemoryData(dat_ptr);
		//}
	}

	//第十二步：判断磁盘是否不足（可选）
	if (IsOutOfDiskSpace())
	{
		std::cout << "磁盘空间不足" << std::endl;
	}

	//if (fp)
	//{
	//	fclose(fp);
	//	fp = nullptr;
	//}

	auto ittr_end_time = std::chrono::system_clock::now();
	auto elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(ittr_end_time - ittr_start_t);
	int count = elapsed.count();
	std::cout << "Start get data T2 Elapsed: " << count << std::endl;
}

void StartT1FromT2()
{
	int nBoard = FTMT_BOARD_D;
	/*int nMask = CH_MASK_0 | CH_MASK_1 | CH_MASK_2 | CH_MASK_3 | CH_MASK_4 | CH_MASK_5 | CH_MASK_6 | CH_MASK_7 | CH_MASK_8 |
		CH_MASK_9 | CH_MASK_10 | CH_MASK_11 | CH_MASK_12 | CH_MASK_13 | CH_MASK_14 | CH_MASK_15;*/

	int nMask = CH_MASK_ALL;
	int nRunMode = FTMT_TASK_RUN_MODE_T2T1;
	int nSaveMode = FTMT_FILE_SAVE_MODE_TEXT;
	int nFilterMode = FTMT_FILE_SERIES_MODE_EACH;
	int nConnectionSucceeded = 0;
	int nStartThreShold = 1000; //OK
	int nStopThreShold = 1000;  //OK
	int nEndMode = FTMT_TTTR_END_MODE_TIME;
	float nInterval = 0.1f;
	bool isEnableMemory = true;
	float fstatisticstimes = 10;
	bool isEnablePermanentTask = true;
	bool isConcurrentMode = false;
	int nMaxEvent = 1000;

	//第一步：设置采集时间
	if (FTMT_ERROR_NONE != SetStatisticsTime(nRunMode, 1))
	{
		std::cout << "T2 功能测试时 SetStatisticsTime 设置失败" << std::endl;

		return;
	}

	//第二步：设置保存文件格式
	if (FTMT_ERROR_NONE != SetFileMode(nRunMode, FTMT_FILE_SAVE_MODE_TEXT, FTMT_FILE_SERIES_MODE_LAST))
	{
		std::cout << "T2 功能测试时 SetFileMode 设置失败：" << nSaveMode << std::endl;

		return;
	}

	//第三步：设置保存文件大小（可选）
	if (SetMaxFileSize(nRunMode, 0, 1024 * 10, 100) != FTMT_ERROR_NONE)
	{
		std::cerr << "SetMaxFileSize Error" << std::endl;
	}

	//获取设备类型
	//第四步：设置文件保存的路径
	if (FTMT_ERROR_NONE != SetFilePath(0, nRunMode, "G:\\Siminics"))
	{
		std::cout << "设备Id为：" << 0 << ",对应的文件保存路径设置失败!" << std::endl;
	}

	//第五步：设置保存文件名（可选）
	if (FTMT_ERROR_NONE != SetFileName(0, nRunMode, 0, "123456"))
	{
		std::cout << "设备Id为：" << 0 << ",对应的文件保存路径设置失败!" << std::endl;
	}

	
	//使能T2模式
	//第六步：使能TTTR模式
	if (FTMT_ERROR_NONE != EnableTTTR(0, FTMT_BOARD_A, nMask))
	{
		std::cout << "板卡使能失败" << std::endl;
	}

	//第七步：设置TRRR停止方式
	if (FTMT_ERROR_NONE != SetTTTREndMode(FTMT_TTTR_END_MODE_TIME, 0))
	{
		std::cout << "时间停止方式设置失败" << std::endl;
		return;
	}
	else
	{
		std::cout << "时间停止方式设置成功" << std::endl;
	}

	//第八步：设置柱状图Bin的个数
	SetBinSize(0, 65536);
	//第九步：设置柱状图纵坐标叠加的最大值
	SetMaxBarValue(65536);

	//初始化T2T1模式，参数依次为：设备ID，参考通道编号(0~32)，模式填0，时间分辨率，最大事件数
	//第十步：初始化T2生成柱状图模式
	InitT2T1Mode(0, 0, 0, 16, 65536);

	std::chrono::time_point<std::chrono::system_clock> ittr_start_t = std::chrono::system_clock::now();

	//第十一步：开始采集
	if (FTMT_ERROR_NONE != StartTask(nRunMode))
	{
		std::cerr << "StartTask Error!" << std::endl;
	}

	unsigned int nLastRefreshCount = 0;
	unsigned int nMax = 0;
	unsigned int nXLastNoZeroValue = 0;
	unsigned long long uYMax64 = 0;
	uint64_t nRefreshCount = 0;

	unsigned long long* datadata = nullptr;
	datadata = new unsigned long long[65536];
	memset(datadata, 0, 65536);
	char filename[256]{ 0 };
	//第十一步：判断任务结束（注：即使自己手动调用StopTask停止，之后也要调用此函数）
	while (IsTaskCompleted() != FTMT_ERROR_NONE)
	{
		std::this_thread::sleep_for(std::chrono::milliseconds(100));

		GetT1Status(&nMax, &nXLastNoZeroValue, &uYMax64, &nRefreshCount, filename);
		//std::cout << "GetFileName:" << filename << std::endl;
		std::cout << "nMax:" << nMax << ",uYMax64:" << uYMax64 << "___nRefreshCount:" << nRefreshCount<<"---nXLastNoZeroValue:"<< nXLastNoZeroValue << std::endl;

			//if (GetT1Data(0, 1, datadata) != FTMT_ERROR_NONE)
			//{
			//	continue;
			//}

		//for (int i = 1; i < 32; i++)
		//{
		//	if (GetT1Data(0, i, datadata) != FTMT_ERROR_NONE)
		//	{
		//		continue;
		//	}
		//}

		//for (int i = 0; i < 65536; i++)
		//{
		//	if (datadata[i] > 0)
		//	{
		//		std::cout << "i:" << i << ",,datadata:" << datadata[i] << std::endl;
		//	}
		//}

		//char filename[256]{ 0 };
		//GetFileName(0, true, filename, 256);
		//std::cout << "GetFileName:" << filename << std::endl;

		//std::this_thread::sleep_for(std::chrono::milliseconds(10));
		/*auto ittr_start_time111 = std::chrono::system_clock::now();
		if (GetT1Data(FTMT_CHANNEL_0, 0, datadata) != FTMT_ERROR_NONE)
		{
			continue;
		}

		auto start_end_time111 = std::chrono::system_clock::now();
		auto start_elapsed111 = std::chrono::duration_cast<std::chrono::milliseconds>(start_end_time111 - ittr_start_time111);*/
		//std::cout << "start_elapsed222:" << start_elapsed111.count() << std::endl;


		//std::this_thread::sleep_for(std::chrono::milliseconds(100));

		/*for (int i = 0; i < 3; ++i)
		{
			uint64_t* datadata = nullptr;
			datadata = new uint64_t[FTMT_T1_DATA_LEN];
			memset(datadata, 0, FTMT_T1_DATA_LEN);
			if (GetT1Data(FTMT_CHANNEL_0, i, datadata) != FTMT_ERROR_NONE)
			{
				continue;
			}*/

			/*delete []datadata;
			datadata = nullptr;*/
			/*uint32_t x;
			uint32_t z;
			uint64_t y;
			uint32_t count;
			GetT1Status(&x,&z, &y, &count);
			std::cout << "count:" << count << std::endl;*/
			//}
			//std::cout << "IsTaskCompleted" << std::endl;
			//uint32_t x;
			//uint32_t z;
			//uint64_t y;
			//uint32_t count;
			//GetT1Status(&x, &z, &y, &count);
			//std::cout << "x:" << x << ",y:" << y << std::endl;
	}

	//std::uint64_t uYMaxValue = 0;
	//for (int i = 0; i < 65536; i++)
	//{
	//	if (datadata[i] > 0)
	//	{
	//		if (uYMaxValue < datadata[i])
	//		{
	//			uYMaxValue = datadata[i];
	//		}
	//		std::cout << "i:" << i << ",,datadata:" << datadata[i] << std::endl;
	//	}
	//}

	//std::cout << "uYMaxValue:" << uYMaxValue << std::endl;

	delete[]datadata;
	datadata = nullptr;
	auto ittr_end_time = std::chrono::system_clock::now();
	auto elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(ittr_end_time - ittr_start_t);
	int count = elapsed.count();
	std::cout << "Start get data T2 Elapsed: " << count << std::endl;
}


void StartT3Default()
{
	int nMask = CH_MASK_0 | CH_MASK_1 | CH_MASK_2 | CH_MASK_3 /*| CH_MASK_4 | CH_MASK_5 | CH_MASK_6 | CH_MASK_7 | CH_MASK_8 |
		CH_MASK_9 | CH_MASK_10 | CH_MASK_11 | CH_MASK_12 | CH_MASK_13 | CH_MASK_14 | CH_MASK_15*/;
	int nRunMode = FTMT_TASK_RUN_MODE_T3;
	int nSaveMode = FTMT_FILE_SAVE_MODE_TEXT;
	int nFilterMode = FTMT_FILE_SERIES_MODE_EACH;
	int nConnectionSucceeded = 0;
	int nStartThreShold = -100; //OK
	int nStopThreShold = -100;  //OK
	int nEndMode = FTMT_TTTR_END_MODE_TIME;
	float nInterval = 0.1f;
	float fstatisticstimes = 10;
	bool isEnableMemory = true;
	bool isEnablePermanentTask = true;
	bool isConcurrentMode = false;
	int nMaxEvent = 1000;


	//第一步：设置采集时间
	if (FTMT_ERROR_NONE != SetStatisticsTime(nRunMode, 1))
	{
		std::cout << "T3 功能测试时 SetStatisticsTime 设置失败" << std::endl;

		return;
	}
	else
	{
		std::cout << "T3 功能测试时 SetStatisticsTime 设置成功" << "s" << std::endl;
	}

	//第二步：设置保存文件类型
	if (FTMT_ERROR_NONE != SetFileMode(nRunMode, FTMT_FILE_SAVE_MODE_TEXT, FTMT_FILE_SERIES_MODE_LAST))
	{
		std::cout << "T3 功能测试时 SetFileMode 设置失败：" << nSaveMode << std::endl;

		return;
	}
	else
	{
		std::cout << "T3 功能测试时 SetFileMode 设置成功：" << nSaveMode << std::endl;
	}

	//第三步：设置保存文件大小（可选）
	if (SetMaxFileSize(nRunMode, 0, 512, 100) != FTMT_ERROR_NONE)
	{
		std::cerr << "SetMaxFileSize Error" << std::endl;
	}

		//获取设备类型
		//第四步：设置保存文件的路径
		if (FTMT_ERROR_NONE != SetFilePath(nDeviceId, nRunMode, "G:\\Siminics"))
		{
			std::cout << "设备Id为：" << nDeviceId << ",对应的文件保存路径设置失败!" << std::endl;
		}
		//使能T2模式
		//第五步：使能T3模式
		if (FTMT_ERROR_NONE != EnableTTTR(nDeviceId, FTMT_BOARD_A, nMask))
		{
			std::cout << "设备Id：" << nDeviceId << ",板" << FTMT_BOARD_A << ",使能失败" << std::endl;
		}


	//第六步：设置T3停止方式
	if (FTMT_ERROR_NONE != SetTTTREndMode(FTMT_TTTR_END_MODE_TIME, 50000))
	{
		std::cout << "时间停止方式设置失败" << std::endl;
		return;
	}
	else
	{
		std::cout << "时间停止方式设置成功" << std::endl;
	}

	std::chrono::time_point<std::chrono::system_clock> ittr_start_t = std::chrono::system_clock::now();
	//第七步：开始采集
	if (FTMT_ERROR_NONE != StartTask(nRunMode))
	{
		std::cerr << "StartTask Error!" << std::endl;
	}

	char buffer[1024]{ 0 };
	unsigned int arrIntensity[32]{ 0 };
	//第八步：判断任务结束（注：即使自己手动调用StopTask停止，之后也要调用此函数）
	while (IsTaskCompleted() != FTMT_ERROR_NONE)
	{
		std::this_thread::sleep_for(std::chrono::milliseconds(10));
		//std::cout << "GetFileName:" << GetFileName(0, false, buffer, 1024) << "___:" << buffer << std::endl;
	}

	auto ittr_end_time = std::chrono::system_clock::now();
	auto elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(ittr_end_time - ittr_start_t);
	int count = elapsed.count();
	std::cout << "Start get data T2 Elapsed: " << count << std::endl;
}

int TestCo()
{

	//第一步：判断设备的连通性
	if (!DevConnected(0))
	{
		std::cout << "设备连接失败" << std::endl;
	}

	//第二步：设置保存文件类型
	if (FTMT_ERROR_NONE != SetFileMode(FTMT_TASK_RUN_MODE_CO, FTMT_FILE_SAVE_MODE_BIN, FTMT_FILE_SERIES_MODE_LAST))
	{
		std::cout << "T3 功能测试时 SetFileMode 设置失败" << std::endl;
	}

	//第三步：设置文件保存路径
	if (SetFilePath(0, FTMT_TASK_RUN_MODE_CO, "G:\\Siminics") != FTMT_ERROR_NONE)
	{
		std::cout << "文件保存路径设置失败" << std::endl;
	}

	//第四步：设置采集时间
	if (SetStatisticsTime(FTMT_TASK_RUN_MODE_CO, 1) != FTMT_ERROR_NONE)
	{
		std::cout << "统计时间设置失败" << std::endl;
	}

	//数据符合模式初始化
	//第五步：初始化符合参数
	if (DmtchInitialize(0, 0) != FTMT_ERROR_NONE)
	{
		std::cout << "数据符合初始化失败" << std::endl;
	}
	
	//第六步：设置符合类型（在线或者离线）
	if (DmtchModeSelection(0, 0))
	{
		std::cout << "数据符合初始化失败" << std::endl;
	}

	int start1[] = { 0,1 };
	int start2[] = { 0,1 };
	int start3[] = { 0,1 };
	int start4[] = { 0,1 };
	int start5[] = { 1,5,3 };
	int start6[] = { 1,5,3 };
	int start7[] = { 1,5,7 };
	int start8[] = { 1,5,7 };
	int start9[] = { 3,5,7 };
	int start10[] = { 3,5,7 };
	int start11[] = { 1,5,7 };
	int start12[] = { 1,5,7 };
	
	//第七步：添加策略
	if (DmtchAddStrategy(1, start1, sizeof(start1) / sizeof(int), 1000, 1, 0, 0, 0, false) != FTMT_ERROR_NONE)
	{
		std::cout << "符合策略1添加失败" << std::endl;
	}

	if (DmtchAddStrategy(2, start2, sizeof(start2) / sizeof(int), 1000, 1, 0, 0, 0, false) != FTMT_ERROR_NONE)
	{
		std::cout << "符合策略2添加失败" << std::endl;
	}

	if (DmtchAddStrategy(3, start3, sizeof(start3) / sizeof(int), 1000, 1, 0, 0, 0, false) != FTMT_ERROR_NONE)
	{
		std::cout << "符合策略3添加失败" << std::endl;
	}

	if (DmtchAddStrategy(4, start4, sizeof(start4) / sizeof(int), 1000, 1, 0, 0, 0, false) != FTMT_ERROR_NONE)
	{
		std::cout << "符合策略4添加失败" << std::endl;
	}
#if 0
	if (DmtchAddStrategy(5, start5, sizeof(start5) / sizeof(int), 1000, 7200, 0, 0, 0, true) != FTMT_ERROR_NONE)
	{
		std::cout << "符合策略1添加失败" << std::endl;
	}

	if (DmtchAddStrategy(6, start6, sizeof(start6) / sizeof(int), 1000, 7200, 0, 0, 0, true) != FTMT_ERROR_NONE)
	{
		std::cout << "符合策略1添加失败" << std::endl;
	}

	if (DmtchAddStrategy(7, start7, sizeof(start7) / sizeof(int), 1000, 7200, 0, 0, 0, true) != FTMT_ERROR_NONE)
	{
		std::cout << "符合策略1添加失败" << std::endl;
	}

	if (DmtchAddStrategy(8, start8, sizeof(start8) / sizeof(int), 1000, 7200, 0, 0, 0, true) != FTMT_ERROR_NONE)
	{
		std::cout << "符合策略1添加失败" << std::endl;
	}

	if (DmtchAddStrategy(9, start9, sizeof(start9) / sizeof(int), 1000, 7200, 0, 0, 0, true) != FTMT_ERROR_NONE)
	{
		std::cout << "符合策略1添加失败" << std::endl;
	}

	if (DmtchAddStrategy(10, start10, sizeof(start10) / sizeof(int), 1000, 7200, 0, 0, 0, true) != FTMT_ERROR_NONE)
	{
		std::cout << "符合策略1添加失败" << std::endl;
	}

	if (DmtchAddStrategy(11, start11, sizeof(start11) / sizeof(int), 1000, 7200, 0, 0, 0, true) != FTMT_ERROR_NONE)
	{
		std::cout << "符合策略1添加失败" << std::endl;
	}

	if (DmtchAddStrategy(12, start12, sizeof(start12) / sizeof(int), 1000, 7200, 0, 0, 0, true) != FTMT_ERROR_NONE)
	{
		std::cout << "符合策略1添加失败" << std::endl;
	}
#endif

	
	auto ittr_start_time = std::chrono::system_clock::now();

	//第八步：开始任务
	if (StartTask(FTMT_TASK_RUN_MODE_CO) != FTMT_ERROR_NONE)
	{
		std::cout << "StartTask Error" << std::endl;
		return -1;
	}
	std::cout << "Start " << std::endl;
	auto start_end_time = std::chrono::system_clock::now();

	uint64_t start1_cnt;
	uint64_t start2_cnt;
	uint64_t chl_cnt[64]{ 0 };
	char FileName[1024]{ "" };
	char FilePath[1024]{ "" };
	//第九步：判断任务结束（注：即使自己手动调用StopTask停止，之后也要调用此函数）
	while (FTMT_ERROR_NONE != IsTaskCompleted())
	{
		std::this_thread::sleep_for(std::chrono::milliseconds(300));

		//////获取策略1的符合数
		if (DmtchGetStratgyCount(1, &start1_cnt))
		{
			std::cout << "start1_cnt:" << start1_cnt << std::endl;
		}

		DmtchGetChlCount(chl_cnt);

		for (int i = 0; i < 8; i++)
		{
			if (chl_cnt[i] > 0)
			{
				std::cout << "i: " << i << "___" << chl_cnt[i] << std::endl;
			}
		}
	}

	//第十步：获取符合结果和通道计数（注：在每次IsTaskCompleted返回FTMT_ERROR_NONE之后，再调用一次DmtchGetStratgyCount和DmtchGetChlCount）
	//////获取策略1的符合数
	if (DmtchGetStratgyCount(1, &start1_cnt))
	{
		std::cout << "start1_cnt:" << start1_cnt << std::endl;
	}

	DmtchGetChlCount(chl_cnt);

	for (int i = 0; i < 8; i++)
	{
		if (chl_cnt[i] > 0)
		{
			std::cout << "i: " << i << "___" << chl_cnt[i] << std::endl;
		}
	}

	auto task_end_time = std::chrono::system_clock::now();
	auto start_elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(start_end_time - ittr_start_time);

	auto task_elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(task_end_time - ittr_start_time);


	std::cout << "StartTask Consumed: " << start_elapsed.count() << "    Total time: " << task_elapsed.count() << std::endl;

	std::cout << "采集结束" << std::endl;

	return 0;
}

int main()
{
	//SetStopThreshold(0, 0, 0, -100);
	while (InitDll() != FTMT_ERROR_NONE)
	{
		std::cout << "DLL 初始化中" << std::endl;
		std::this_thread::sleep_for(std::chrono::milliseconds(100));
	}

	//DLL初始化完成
	std::cout << "DLL 初始化完成" << std::endl;

	while (InitDev() != FTMT_ERROR_NONE)
	{
		std::this_thread::sleep_for(std::chrono::milliseconds(100));
	}

	//SetOnlineOfflineMode(1);
	//InitDll();
	//InitDev();

	//设备初始化完成
	std::cout << "设备初始化完成" << std::endl;

	unsigned int nDevType;
	GetDevType(0, &nDevType);
	std::cout << "nDevType:" << nDevType << std::endl;

	while (true)
	{
		TestCo();
		std::this_thread::sleep_for(std::chrono::milliseconds(1000));
	}


	int nConn = 0;
	GetConnectionMode(0, &nConn);
	std::cout << "nConn:" << nConn << std::endl;

	UnInitDll();
	std::cout << std::endl << std::endl;
	std::cout << "end test..." << std::endl << std::endl;

	//std::cout << "nCount:" << nCount << std::endl;

	//CleanFlim();
	getchar();
	//doubleSpinBoxBlock
	//system("pause");
	return 0;
}
//EB 90 B0 F1