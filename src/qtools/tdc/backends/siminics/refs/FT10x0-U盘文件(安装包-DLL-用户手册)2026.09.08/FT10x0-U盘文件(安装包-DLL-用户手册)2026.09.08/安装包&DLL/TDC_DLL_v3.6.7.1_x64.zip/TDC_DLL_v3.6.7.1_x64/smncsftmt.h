#ifndef SMNCSFTMT_H_
#define SMNCSFTMT_H_
//#include <stdint.h>
//device connected types
#define FTMT_DEV_CONNECTED_USB			(1)
#define FTMT_DEV_CONNECTED_ETH			(2)

#define FTMT_ON_LINE_STATUS				(1)
#define FTMT_OFF_LINE_STATUS			(0)

//device types
#define FTMT_DEV_TYPE_FT1010			(0x1010)
#define FTMT_DEV_TYPE_FT1040			(0x1040)
#define FTMT_DEV_TYPE_FT1080			(0x1080)
#define FTMT_DEV_TYPE_MT6420			(0x6420)
#define FTMT_DEV_TYPE_MT04				(0x0004)
#define FTMT_DEV_TYPE_MT08				(0x0008)
#define FTMT_DEV_TYPE_MT16				(0x0016)
#define FTMT_DEV_TYPE_MTQ04				(0x0104)
#define FTMT_DEV_TYPE_MTQ08				(0x0108)
#define FTMT_DEV_TYPE_MTQ16				(0x0116)
#define FTMT_DEV_TYPE_MTQ32				(0x0132)
#define FTMT_DEV_TYPE_ST08				(0xA0000008)
#define FTMT_DEV_TYPE_PT16				(0xB0000016)

//Start signal frequency division(MT4C16 is not supported)
#define FTMT_START_FREQ_DIV_1			(1)
#define FTMT_START_FREQ_DIV_2			(2)
#define FTMT_START_FREQ_DIV_4			(4)
#define FTMT_START_FREQ_DIV_8			(8)

//resolution
#define FTMT_WIN_RES_PS_1				(0)
#define FTMT_WIN_RES_PS_2				(1)
#define FTMT_WIN_RES_PS_4				(2)
#define FTMT_WIN_RES_PS_8				(3)
#define FTMT_WIN_RES_PS_16				(4)
#define FTMT_WIN_RES_PS_32				(5)
#define FTMT_WIN_RES_PS_64				(6)
#define FTMT_WIN_RES_PS_128				(7)
#define FTMT_WIN_RES_PS_256				(8)
#define FTMT_WIN_RES_PS_512				(9)
#define FTMT_WIN_RES_PS_1024			(10)
#define FTMT_WIN_RES_PS_2048			(11)
#define FTMT_WIN_RES_PS_4096			(12)
#define FTMT_WIN_RES_PS_8192			(13)
#define FTMT_WIN_RES_PS_16384			(14)
#define FTMT_WIN_RES_PS_32768			(15)
#define FTMT_WIN_RES_PS_65536			(16)
#define FTMT_WIN_RES_PS_131072			(17)
#define FTMT_WIN_RES_PS_262144			(18)
#define FTMT_WIN_RES_PS_524288			(19)
#define FTMT_WIN_RES_PS_1048576			(20)
#define FTMT_WIN_RES_PS_2097152			(21)
#define FTMT_WIN_RES_PS_4194304			(22)
#define FTMT_WIN_RES_PS_8388608			(23)
#define FTMT_WIN_RES_PS_16777216		(24)
#define FTMT_WIN_RES_PS_33554432		(25)

//Run mode
#define FTMT_TASK_RUN_MODE_T1			(0x01)
#define FTMT_TASK_RUN_MODE_T2			(0x02)
#define FTMT_TASK_RUN_MODE_T3			(0x03)
#define FTMT_TASK_RUN_MODE_CO			(0x04)
#define FTMT_TASK_RUN_MODE_FLIM			(0x05)
#define FTMT_TASK_RUN_MODE_ITTR_T		(0x06)
#define FTMT_TASK_RUN_MODE_ITTR_M		(0x07)
#define FTMT_TASK_RUN_MODE_G2		    (0x08)
#define FTMT_TASK_RUN_MODE_MULTI_CO		(0x09)
#define FTMT_TASK_RUN_MODE_HISTOGRAM    (0x11)
#define FTMT_TASK_RUN_MODE_T2T1			(0x12)
#define FTMT_TASK_RUN_MODE_T3T1			(0x13)
#define FTMT_TASK_RUN_MODE_IDLE			(0x10)
#define FTMT_TASK_RUN_MODE_ERR			(0x20)

//Board number
#define FTMT_BOARD_A				(0)
#define FTMT_BOARD_B				(1)
#define FTMT_BOARD_C				(2)
#define FTMT_BOARD_D				(3)
#define FTMT_BOARD_E				(4)
#define FTMT_BOARD_F				(5)
#define FTMT_BOARD_G				(6)
#define FTMT_BOARD_H				(7)

//Channel number
#define FTMT_CHANNEL_0				(0)
#define FTMT_CHANNEL_1				(1)
#define FTMT_CHANNEL_2				(2)
#define FTMT_CHANNEL_3				(3)
#define FTMT_CHANNEL_4				(4)
#define FTMT_CHANNEL_5				(5)
#define FTMT_CHANNEL_6				(6)
#define FTMT_CHANNEL_7				(7)
#define FTMT_CHANNEL_8				(8)
#define FTMT_CHANNEL_9				(9)
#define FTMT_CHANNEL_10				(10)
#define FTMT_CHANNEL_11				(11)
#define FTMT_CHANNEL_12				(12)
#define FTMT_CHANNEL_13				(13)
#define FTMT_CHANNEL_14				(14)
#define FTMT_CHANNEL_15				(15)
#define FTMT_CHANNEL_16				(16)
#define FTMT_CHANNEL_17				(17)
#define FTMT_CHANNEL_18				(18)
#define FTMT_CHANNEL_19				(19)
#define FTMT_CHANNEL_20				(20)
#define FTMT_CHANNEL_21				(21)
#define FTMT_CHANNEL_22				(22)
#define FTMT_CHANNEL_23				(23)
#define FTMT_CHANNEL_24				(24)
#define FTMT_CHANNEL_25				(25)
#define FTMT_CHANNEL_26				(26)
#define FTMT_CHANNEL_27				(27)
#define FTMT_CHANNEL_28				(28)
#define FTMT_CHANNEL_29				(29)
#define FTMT_CHANNEL_30				(30)
#define FTMT_CHANNEL_31				(31)

//Save type
#define FTMT_FILE_SAVE_MODE_NONE		(0)
#define FTMT_FILE_SAVE_MODE_BIN			(1)
#define FTMT_FILE_SAVE_MODE_TEXT		(2)

//Save mode
#define FTMT_FILE_SERIES_MODE_EACH		(0)
#define FTMT_FILE_SERIES_MODE_LAST		(1)

//Save cut
#define FTMT_FILE_CUT_MODE_NONE			(0)
#define FTMT_FILE_CUT_MODE_SIZE			(1)
#define FTMT_FILE_CUT_MODE_TIME			(2)

//TTTR end mode
#define FTMT_TTTR_END_MODE_TIME			(0)
#define FTMT_TTTR_END_MODE_EVENT		(1)

//ITTR end mode
#define FTMT_ITTR_END_MODE_TIME			(0)
#define FTMT_ITTR_END_MODE_EVENT		(1)

//Input impedence(only FT10X0)
#define FT10X0_INPUT_IMPEDENCE_HIGH		(0)
#define FT10X0_INPUT_IMPEDENCE_50		(1)

//only MT4C16
#define MT4C16_INPUT_IMPEDENCE_HIGH		(0)
#define MT4C16_INPUT_IMPEDENCE_50		(1)

#define FT10X0_INPUT_EDGE_RISE			(0)
#define FT10X0_INPUT_EDGE_FALL			(1)

#define MT4C16_INPUT_EDGE_RISE			(0)
#define MT4C16_INPUT_EDGE_FALL			(1)

#define FTMT_FILENAME_AUTO			(0)
#define FTMT_FILENAME_MANUAL			(1)

#define CH_MASK_0				((unsigned int)(0x01))
#define CH_MASK_1				((unsigned int)(0x01<<FTMT_CHANNEL_1))
#define CH_MASK_2				((unsigned int)(0x01<<FTMT_CHANNEL_2))
#define CH_MASK_3				((unsigned int)(0x01<<FTMT_CHANNEL_3))
#define CH_MASK_4				((unsigned int)(0x01<<FTMT_CHANNEL_4))
#define CH_MASK_5				((unsigned int)(0x01<<FTMT_CHANNEL_5))
#define CH_MASK_6				((unsigned int)(0x01<<FTMT_CHANNEL_6))
#define CH_MASK_7				((unsigned int)(0x01<<FTMT_CHANNEL_7))
#define CH_MASK_8				((unsigned int)(0x01<<FTMT_CHANNEL_8))
#define CH_MASK_9				((unsigned int)(0x01<<FTMT_CHANNEL_9))
#define CH_MASK_10				((unsigned int)(0x01<<FTMT_CHANNEL_10))
#define CH_MASK_11				((unsigned int)(0x01<<FTMT_CHANNEL_11))
#define CH_MASK_12				((unsigned int)(0x01<<FTMT_CHANNEL_12))
#define CH_MASK_13				((unsigned int)(0x01<<FTMT_CHANNEL_13))
#define CH_MASK_14				((unsigned int)(0x01<<FTMT_CHANNEL_14))
#define CH_MASK_15				((unsigned int)(0x01<<FTMT_CHANNEL_15))
#define CH_MASK_16				((unsigned int)(0x01<<FTMT_CHANNEL_16))
#define CH_MASK_17				((unsigned int)(0x01<<FTMT_CHANNEL_17))
#define CH_MASK_18				((unsigned int)(0x01<<FTMT_CHANNEL_18))
#define CH_MASK_19				((unsigned int)(0x01<<FTMT_CHANNEL_19))
#define CH_MASK_20				((unsigned int)(0x01<<FTMT_CHANNEL_20))
#define CH_MASK_21				((unsigned int)(0x01<<FTMT_CHANNEL_21))
#define CH_MASK_22				((unsigned int)(0x01<<FTMT_CHANNEL_22))
#define CH_MASK_23				((unsigned int)(0x01<<FTMT_CHANNEL_23))
#define CH_MASK_24				((unsigned int)(0x01<<FTMT_CHANNEL_24))
#define CH_MASK_25				((unsigned int)(0x01<<FTMT_CHANNEL_25))
#define CH_MASK_26				((unsigned int)(0x01<<FTMT_CHANNEL_26))
#define CH_MASK_27				((unsigned int)(0x01<<FTMT_CHANNEL_27))
#define CH_MASK_28				((unsigned int)(0x01<<FTMT_CHANNEL_28))
#define CH_MASK_29				((unsigned int)(0x01<<FTMT_CHANNEL_29))
#define CH_MASK_30				((unsigned int)(0x01<<FTMT_CHANNEL_30))
#define CH_MASK_31				((unsigned int)(0x01<<FTMT_CHANNEL_31))
#define CH_MASK_NONE			((unsigned int)(0x0000))
#define CH_MASK_ALL				((unsigned int)(0xFFFFFFFF))

//device number
#define DEV_ID_0				(0)
#define DEV_ID_1				(1)
#define DEV_ID_2				(2)
#define DEV_ID_3				(3)
#define DEV_ID_4				(4)
#define DEV_ID_5				(5)
#define DEV_ID_6				(6)
#define DEV_ID_7				(7)
#define DEV_MAX_NUMBER				(8)

//error code
#define FTMT_ERROR_NONE					(0)					//no error
#define FTMT_ERROR_CONNECT				(0x1001)			//connection error
#define FTMT_ERROR_SYSTEM_BUSY			(0x1002)			//system is running on another task
#define FTMT_ERROR_PARAM				(0x1003)			//parameter specified is incorrect
#define FTMT_ERROR_MEMORY_ACCESS		(0x1004)			//memory specified could not be accessed	
#define FTMT_ERROR_MEMORY_LOW			(0x1005)			//operating system memory is low
#define FTMT_ERROR_FILE_ACCESS			(0x1006)			//file/directory specified could not be accessed
#define FTMT_ERROR_CHANNEL_ENABLE		(0x1007)			//no channel is enabled for operation
#define FTMT_ERROR_TTTR_ENABLE			(0x1008)			//no tttr is enabled for operation
#define FTMT_ERROR_BOARD_ENABLE			(0x1009)			//no board is enabled for operation
#define FTMT_ERROR_NO_MODE				(0x1010)			//the mode is not defined
#define FTMT_ERROR_MODE_MATCH			(0x1011)			//the mode specified does not match with system
#define FTMT_ERROR_START_LIMIT			(0x1012)			//strategy definition failed due to resource limit
#define FTMT_ERROR_DLL_INIT				(0x1013)			//DLL init failed
#define FTMT_ERROR_FPGA_READY			(0x1014)
#define FTMT_ERROR_FATAL				(0x1015)			//fatal error, please reload the dll

#define FTMT_ERROR_NULLPTR				(0x1016)			//The passed in pointer is null
#define FTMT_ERROR_DEV_NUMBER			(0x1017)			//Device number error (Should enter,0~7)
#define FTMT_ERROR_NO_SUPPORT			(0x1018)			//no support
#define FTMT_ERROR_CHANNEL				(0x1019)			//channel number error
#define FTMT_ERROR_BOARD				(0x1020)			//board number error
#define FTMT_ERROR_FILE_NOT_EXIST		(0x1021)			//file does not exist
#define FTMT_ERROR_INVALID_DATA			(0x1022)            //invalid data
#define FTMT_ERROR_FITTING_FAILED		(0x1023)			//Fitting failed

#define FT1010_CHANNEL_NUM			(1)					//FT1010 channel num
#define FT1040_CHANNEL_NUM			(4)					//FT1040 channel num
#define FT1080_CHANNEL_NUM			(8)					//FT1080 channel num
#define MT04_CHANNEL_NUM			(4)					//MT04 channel num
#define MT08_CHANNEL_NUM			(8)					//MT08 channel num
#define MT16_CHANNEL_NUM			(16)				//MT16 channel num
#define MTQ_CHANNEL_NUM			    (32)				//MT16 channel num

#define MT6420_BOARD_NUM			(8)					//MT6420 board num
#define MT6420_CHANNEL_NUM_PER_BOARD		(8)					//MT6420 channel num

#define FTMT_T1_DATA_LEN			(65536*16)		
#define FTMT_DMTCH_BAR_LEN			(65536)

#define DMTCH_MODE_ONLINE			(0)					//online
#define DMTCH_MODE_OFFLINE			(1)					//offline
#define DMTCH_MODE_LOCAL			(2)

#define FTMT_DATA_TYPE_T2			(0)
#define FTMT_DATA_TYPE_T3			(1)

#define FTMT_G2_ONLINE				(0)
#define FTMT_G2_OFFLINE				(1)
#define FTMT_G2_LOCAL				(2)

#define FTMT_MULTI_CO_ONLINE		(0)
#define FTMT_MULTI_CO_OFFLINE		(1)
#define FTMT_MULTI_CO_LOCAL			(2)

#define FTMT_CO_ONLY_RESULT				(0)    //Save results only
#define FTMT_CO_RESULT_DATA				(1)    //Save the results that match the data

#define FLIM_FILTER_DATA_FLOOR		  (0)
#define FLIM_FILTER_DATA_SEL_CHL      (1)

#define FTMT_T1_ONLINE		(0)
#define FTMT_T1_LOCAL		(1)

typedef struct tagFtmtRawData
{
	int				nType;
	long			lLength;
	unsigned char* ptrData;
}FtmtRawData;

typedef struct tagFtmtParsedRecord
{
	int				nFlag;			// 0=data, 1=marker
	int				nChannel;		// Channel number (human-readable)
	unsigned long long	uTimeBin;	// Time in bins
	unsigned long long	uTimePs;		// Time in picoseconds
}FtmtParsedRecord;

typedef struct tagFtmtParsedData
{
	int				nType;			// Data type (T2=0, T3=1)
	long			lCount;			// Number of records
	FtmtParsedRecord* ptrRecords;	// Array of parsed records
}FtmtParsedData;

struct PeriodData {
	bool isFlag;
	unsigned int nPeriodNumber;  // 周期号
	unsigned int nChlIntensities[MTQ_CHANNEL_NUM];  // 存储每个周期16个通道的强度值

};

#define MAX_GROUP (256)
#define MAX_CHANNEL_NUM (64)
#define MAX_NAME_SIZE (32)

typedef struct tagSingleGroup
{
	int				nChlNum;
	int				nGroupCount;
	int				nEffectiveType;
	int				nIntegrate;
	unsigned long long			uWinWidth;
	char strGroupName[MAX_NAME_SIZE];	
	int arrChlNo[MAX_CHANNEL_NUM];
	int arrChlFlag[MAX_CHANNEL_NUM];
}SingleGroup;

typedef struct tagSingleCluster
{
	int				nGroupNum;
	int				nGroupCount;
	int				nIntegrate;
	unsigned long long			uWinWidth;
	char strClusterName[MAX_NAME_SIZE];
	int				arrChlNum[MAX_GROUP];
	int				arrGroupCount[MAX_GROUP];
	int				arrEffectiveType[MAX_GROUP];
	int				arrIntegrate[MAX_GROUP];
	unsigned long long			arrWinWidth[MAX_GROUP];
	int arrChlNo[MAX_GROUP][MAX_CHANNEL_NUM];
	int arrChlFlag[MAX_GROUP][MAX_CHANNEL_NUM];
	char strGroupName[MAX_GROUP][MAX_NAME_SIZE];
}SingleCluster;

#define FLIM_PARAM_NUM (5)
#pragma pack(push,1)
typedef struct tagFlimParam
{
	int nSelChl;
	int nNumComponents;
	int nTimeChannelNum;
	float fTcal;
	float irfFwhmNs;

	int nCombine;
	int nFilterData;
	int nStartChl;
	int nStopChl;
	float fFloor;
	float fFPK;
	bool isNormalize;

	float fAlpha[FLIM_PARAM_NUM];
	int nAlphaNum;
	float fTau[FLIM_PARAM_NUM];
	int nTauNum;
	int nActiveNum;

	int nMaxIteration;
	int MaxCalTime;

	float fBackgroundIrf;
	float fBackgroundSig;
	float fScatter;
	float fQShift;
	bool fixBackgroundIrf;
	bool fixBackgroundSig;
	bool fixScatter;
	bool fixQShift;
	bool useExternalInitialValues;
	bool isIRFData;
	bool isEnableSmoothing;
}FlimParam;
#pragma pack(pop)

typedef struct tagComponent {
	double amplitude; // 振幅 (a_i)
	double lifetime; // 寿命 (tau_i)
	double amplitude_ratio; // 振幅比例
}Component;

#ifdef SMNCSFTMT_LIBRARY_BUILD
// Building the library
#ifdef _WINDOWS
	// Use the Windows-specific export attribute
#define TDC_API __declspec(dllexport)
#elif __GNUC__ >= 4
	// Use the GCC-specific export attribute
#define TDC_API __attribute__((visibility("default")))
#else
	// Assume that no export attributes are needed
#define TDC_API
#endif
#else
// Using (including) the library
#ifdef _WINDOWS
	// Use the Windows-specific import attribute
#define TDC_API __declspec(dllimport)
#else
	// Assume that no import attributes are needed
#define TDC_API
#endif
#endif

#ifdef __cplusplus
extern "C"
{
#endif
	TDC_API void SetOnlineOfflineMode(int nMode);

	TDC_API int InitDll();

	TDC_API int InitDev();

	// 上位机关闭时调用：通知 DLL 中止正在进行的设备初始化（不销毁单例）
	TDC_API int AbortDevInit();

	TDC_API int GetConnectionMode(int nDevId, int* nConnectedType);

	TDC_API int UnInitDll();

	TDC_API char* GetDllVersion();

	TDC_API char* GetFPGAVersion(int nDevId, int nBoardNum);

	TDC_API void FreeFPGAString(char* strFPGA);

	TDC_API bool DevConnected(int nDevId);
	
	TDC_API bool GetBoardConn(int nDevId, int nBoard);

	TDC_API int GetDevType(int nDevId, unsigned int* ptrType);

	TDC_API char* GetSerialNumber(int nDevId);

	TDC_API void FreeSerialNumberStr(char* strSerial);

	TDC_API char* GetPartNumber(int nDevId);

	TDC_API void FreePartNumString(char* strPartNum);

	TDC_API unsigned int GetSyncStatus(int nDevId, int nBoard);

	TDC_API unsigned int GetStopStatus(int nDevId, int nBoard, int nChannel);

	TDC_API int GetSignalStatus(int nDevId, int nBoard, int nChannel, unsigned int* ptrStartCount, unsigned int* ptrStopCount);

	//Set parameters
	TDC_API int SetStartFreqDiv(int nDevId, int nFreqDiv);   //1,2,4,8

	TDC_API int GetStartFreqDiv(int nDevId, int nBoard, unsigned int* nFreqDiv);

	TDC_API int SetTimeWindowRes(int nDevId, unsigned int nWinRes); //0~25

	TDC_API int GetTimeWindowRes(int nDevId, int nBoard, unsigned int* nWinRes);

	TDC_API int SetBlockedWindow(int nDevId, float fBlockWind);

	TDC_API int SetStartThreshold(int nDevId, int nBoard, int nStartThrsh);

	TDC_API int SetStopThreshold(int nDevId, int nBoard, int nChannel, int nStopThrsh);

	TDC_API int GetStartStopThreshold(int nDevId, int nBoard, int nChannel, int* nStartThreshold, int* nStopThreshold);

	TDC_API int SetStartDelay(int nDevId, int nBoard, float fDelay);

	TDC_API int SetStopDelay(int nDevId, int nBoard, int nChannel, float fDelay);

	TDC_API int GetStopDelay(int nDevId, int nBoard, int nChannel, float* fDelay);

	TDC_API int SetGateHLWidth(int nDevId, int nWidth);

	TDC_API int GetGateHLWidth(int nDevId, int* nWidth);

	TDC_API int SetGateDelay(int nDevId, int nDelay);

	TDC_API int GetGateDelay(int nDevId, int* nDelay);

	TDC_API int SetGateControl(int nDevId, int nGateControl);

	TDC_API int GetGateControl(int nDevId, int* nGateControl);

	TDC_API int SetStartImpedence(int nDevId, int nImpedence);

	TDC_API int GetStartImpedence(int nDevId, int nBoard, unsigned int* nImpedence);

	TDC_API int SetStopImpedence(int nDevId, int nBoard, int nChannel, int nImpedence);

	TDC_API int GetStopImpedence(int nDevId, int nBoard, int nChannel, unsigned int* nEdge);

	TDC_API int SetStartEdge(int nDevId, int nEdge);

	TDC_API int GetStartEdge(int nDevId, int nBoard, unsigned int* nEdge);

	TDC_API int SetStopEdge(int nDevId, int nBoard, int nChannel, int nEdge);

	TDC_API int GetStopEdge(int nDevId, int nBoard, int nChannel, unsigned int* nEdge);

	TDC_API int SetT1T3WindowBack(int nDevId, int nBoard, unsigned int uWindowBack);

	TDC_API int GetT1T3WindowBack(int nDevId, int nBoard, unsigned int* uWindowBack);

	TDC_API int SetPulseCycle(int nDevId, int nBoard, int nCycle);

	TDC_API int SetFilePath(int nDevId, int nRunMode, const char* strFilePath);

	TDC_API int SetFilePathDual(int nDevId, int nRunMode, const char* strFilePath1, const char* strFilePath2);

	TDC_API bool GetFilePath(int nDevId, int nRunMode, char* buffer, long bufferSize);

	TDC_API void FreeFilePathStr(char* strFilePath);

	TDC_API int SetFileName(int nDevId, int nRunMode, int nAutoNaming, const char* strFileName);

	TDC_API bool GetFileName(int nDevId, bool isIncludePath, char* buffer, long bufferSize);

	TDC_API void FreeFileNameStr(char* strFileName);

	TDC_API int SetFileMode(int nRunMode, int nSaveMode, int nFilterMode);

	TDC_API int SetMaxFileSize(int nRunMode, int nCutMode, unsigned int nFileSize, unsigned int nSplitTime);

	TDC_API int SetStatisticsTime(int nRunMode, float Times);

	//T1
	TDC_API int InitT2T1Mode(int nDevId, int nRefChannel, int nMode, unsigned long long uBinWidth, unsigned int uBinCount);

	TDC_API int InitT3T1Mode(int nDevId, unsigned int uBinWidth, unsigned int uBinCount);

	TDC_API int SetT1Interval(float fIntvl);

	TDC_API int SetBinSize(int nDevId, unsigned int uBinSize);

	TDC_API int SetMaxBarValue(unsigned long long uValue64);

	TDC_API int EnableT1(int nDevId, int nBoard, unsigned int uMask16);

	TDC_API int GetT1Data(int nBoard, int nChannel, unsigned long long* data);

	TDC_API int GetT1Status(unsigned int* uXMax, unsigned int* uXLastNoZeroValue, unsigned long long* uYMax, unsigned long long* uCount, char* strFileName);

	TDC_API int T1ValueOfLocalFile(const char* strFileName);

	TDC_API int StopT1OfLocalFile();

	TDC_API bool IsT1CompletedOfFile(unsigned int* uProgress);

	//ITTR
	TDC_API int EnableITTR(int nDevId, int nBoard, unsigned int uMask);

	TDC_API int SetITTREndMode(int nMode, unsigned long long uEvents64);

	TDC_API int SetITTRInterval(int nDevId, int nBoard, int nIntvl);

	TDC_API int GetIttrDataOverflow(int nDevId, int nBoard, unsigned int* uDataOverflow);

	TDC_API PeriodData GetIttrMIntensity();

	TDC_API int GetIttrTIntensity(unsigned int uIntensity[], int nChlNum);

	//TTTR
	TDC_API int EnableTTTR(int nDevId, int nBoard, unsigned int uMask);

	TDC_API int SetTTTREndMode(int nEndMode, unsigned long long uEvents64);

	TDC_API int GetTttrDataOverflow(int nDevId, int nBoard, unsigned int* uDataOverflow);

	TDC_API int DmtchInitialize(int nDevId, int nBoard);

	TDC_API int DmtchModeSelection(int nDevId, int nMethod);

	TDC_API int DmtchStartOffLine(const char* strFileName);

	TDC_API bool IsDmtchCompleted(unsigned int* uProgress);

	TDC_API int DmtchAddStrategy(int nIndex, int nChannels[], int nNum, float fWinLen, float times, int nRes, float fFreq, int nDataType, unsigned char ucSaveCoData);

	TDC_API bool DmtchGetStratgyCount(int nIndex, unsigned long long *uMatchResult);

	TDC_API bool DmtchGetChlCount(unsigned long long chlCnt[]);

	TDC_API int DmtchGetChlTotalTime(unsigned long long chlTimeCnt[]);

	TDC_API int DmtchStopOffLine();

	TDC_API unsigned long long DmtchGetTotalTime(int nIndex);

	TDC_API int SetG2BinSize(int nDevId, unsigned int uBinSize);

	TDC_API int EnableG2(int nDevId, int nBoard, unsigned int uMask);

	TDC_API int GetG2Data(unsigned long long* data);

	TDC_API int G2Initialize(int nDevId, int nBoard, int ng2Mode, int nStartChl, int nStopChl, int nRes);

	TDC_API int G2ValueOfLocalFile(const char* strFileName);

	TDC_API int StopG2OfLocalFile();

	TDC_API bool IsG2CompletedOfFile(unsigned int* uProgress);

	TDC_API int GetG2Status(unsigned int* uXMax, unsigned int* uXLastNoZeroValue, unsigned int* uXZeroPos, unsigned long long* uYMax, unsigned long long* uSyncCount, unsigned long long* uChlCount, unsigned long long* uSyncTimes, unsigned long long* uChlTimes);

	TDC_API unsigned long long GetG2CollectionTime();

	TDC_API int InitHisArrayMode(int nDevId, int nSync, int nStop1, int nStop2, int nMarkerFlag, unsigned int	uHistogramCount, unsigned int uBinWidth, unsigned int uBinCount);

	TDC_API int GetHisArrayData(int nBoard, unsigned int* nHisIndex, unsigned int* data);

	TDC_API int GetHisArrayPhotonTime(unsigned long long* nStartTotalTimes, unsigned long long* nStop1TotalTimes, unsigned long long* nStop2TotalTimes);

	TDC_API int GetHisArrayPhotonCount(unsigned long long* nStartTotalCount, unsigned long long* nStop1TotalCount, unsigned long long* nStop2TotalCount);

	TDC_API int GetHisXLastZero(unsigned int* nXLastZero, unsigned int* nPrevXLastZero);

	TDC_API int GetHisArrayCount(unsigned int* ptrHistogramCount);

	TDC_API int GetHisPhotonRange(unsigned int* ptrMinPhoton, unsigned int* ptrMaxPhoton);

	TDC_API int MultiBodyInitialize(int nDevId, int nBoard, unsigned long long uTotalTimes);

	TDC_API int MultiBodyModeSelection(int nDevId, int nMethod);

	TDC_API int MultiBodyAddGroup(SingleGroup group[], int nGroupSize);

	TDC_API int MultiBodyAddCluster(SingleCluster cluster[], int nClusterSize);

	TDC_API int MultiBodyStartOffLine(const char* strFileName);

	TDC_API int MultiBodyGetGroupCount(const char* strGroupName, unsigned long long* uGroupCount);

	TDC_API int MultiBodyGetClusterCount(const char* strClusterName, const char* strGroupName, unsigned long long* uClusterCount, unsigned long long* uGroupCount);

	TDC_API int MultiBodyGetChlCount(unsigned long long chlCnt[]);

	TDC_API int MultiBodyStopOffLine();

	TDC_API bool IsMultiCoCompletedOffLine(unsigned int* uProgress);

	TDC_API int InitFlimParam(FlimParam* flimparam);

	TDC_API int StartFlimFit(const char* strSignalFile, const char* strIRFFile);

	TDC_API int GetFlimTimeChannel(unsigned int* uChlNums);

	TDC_API int GetFlimChannelIds(int* chlid);

	TDC_API int GetFlimTimeAxis(double* TimeAxis);
	
	TDC_API int GetFlimPhotonData(int nBoard, int nChannel, double* PhotonData, unsigned int data_size);

	TDC_API int GetFlimIRFData(int nBoard, int nChannel, double* data, unsigned int data_size);

	TDC_API int GetFlimFitData(int nBoard, int nChannel, double* FitData, unsigned int data_size);

	TDC_API int GetFlimResidualsData(int nBoard, int nChannel, double* ResidualsData, unsigned int data_size);

	TDC_API int GetFlimChiSquare(int nBoard, int nChannel, double* fChiSquare);

	TDC_API Component GetFitParam(int nChl, int nComponents);

	TDC_API int CleanFlim();

	TDC_API int StartTask(int nRunMode);

	TDC_API int StopTask(int nRunMode);

	TDC_API int PauseTask();

	TDC_API int ResumeTask();

	TDC_API int IsTaskCompleted();

	TDC_API bool IsOutOfDiskSpace();

	TDC_API int GetRunMode(unsigned int* uRunMode);

	TDC_API int SetMemoryDataMode(bool bEnable);

	TDC_API bool MemoryDataModeEnabled();

	TDC_API FtmtRawData* GetMemoryData(int nDevId);

	TDC_API int ReleaseMemoryData(FtmtRawData* ptrData);

	TDC_API int SetParsedDataMode(bool bEnable);

	TDC_API bool ParsedDataModeEnabled();

	TDC_API FtmtParsedData* GetParsedData(int nDevId);

	TDC_API int ReleaseParsedData(FtmtParsedData* ptrData);

	TDC_API int GetCollectTimes(int nDevId, unsigned long long* uColloctionTimes);

	TDC_API int StartChannelMapping(int nDevId, int nBoard, unsigned char uChannelMapping8);

	TDC_API int SaveConfigParam(int nDevId, int nBoard, unsigned int uValue);

	TDC_API int GetPacketsReceivedDiscarded(long long *uReceivedDiscarded);

	TDC_API int ReadRegister(int nDevId, unsigned char* ReadBuff, unsigned char len, unsigned int* ptrValue, unsigned long long* ptrWholeValue);

	TDC_API int WriteRegister(int nDevId, unsigned char* WriteBuff, unsigned char len, unsigned int Value);

#ifdef __cplusplus
}
#endif
#endif


